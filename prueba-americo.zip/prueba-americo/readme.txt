=== Prueba Americo ===
Contributors: Americo Guzman
Requires at least: 4.0
Tested up to: 4.9
Stable tag: 4.0.1
License: GPLv2 or later
Version:1.0


== Descripcion ==

Prueba Americo es un plugin elaborado para leer informacion de un endpoint, generar un select con las opciones disponibles y desplegar
la informacion en una tabla.

Una de sus caracteristicas principales es que lleva el registro de que opcion a elejido el usuario.

== Instalacion ==

1. Ingresa a Plugins > Añadir Nuevo
2. Haz clic en la pestaña de Subir, selecciona el prueba-americo.zip y después haz clic en Instalar Ahora.
3. Activa el plugin y la instalación estará completa.

== Como Usarlo ==
1. Abra la entrada/página en el panel de administración de WordPress.
2. Seleccione Añadir nueva o elejir editar una pagina existente.
3. Agregar el shortcode [MYFORM] en el contenido y hacer click en Actualizar.
4. Dar click en Vista previa de los cambios.



