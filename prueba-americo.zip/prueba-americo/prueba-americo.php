<?php
/*
Plugin Name: Prueba Americo
Plugin URI: http://wordpress.org/plugins/prueba-americo/
Description: Prueba Tecnica Desarrollador PHP-WORDPRESS
Author: Americo Guzman
Version: 1.0
Author URI: http://americo.org/
*/

//Creamos la base de datos bitacora para guardar los id que se elijan
register_activation_hook( __FILE__, 'my_plugin_create_db' );
function my_plugin_create_db() {

	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'bitacora';

	$sql = "CREATE TABLE $table_name (
		  id int(11) NOT NULL,
		  fecha datetime NOT NULL,
		  usuario varchar(255) NOT NULL,
		  detalle varchar(255) NOT NULL
	) $charset_collate;";

	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}



//Funcion que se encarga de leer el endpoint y generar un select a partir de la informacion.
function show_my_select() {
	
$request = wp_remote_get( 'http://jsonplaceholder.typicode.com/posts/1/comments' );

if( is_wp_error( $request ) ) {
	return false; 
}

$body = wp_remote_retrieve_body( $request );

$data = json_decode( $body );

if( ! empty( $data ) ) {
	
	echo '<b>SELECCIONE UN ID</b><br>';
	echo '<select id="coments">';
	echo '<option value="0">Seleccione una opcion</a>';
	foreach( $data as $comments ) {
		
			echo '<option value="'. $comments->id .'">'. $comments->id .'</a>';
		
	}
	echo '</select><br><br>';
}

echo"<div id='table'></div><br><br><input id='uri' type='hidden' value='".plugins_url( '/save.php', __FILE__ )."'";


}



function select_response() {
    wp_enqueue_script( 'select-response', plugins_url( '/js/select_response.js', __FILE__ ) , array( 'jquery' ), '1.0.0', true );
    wp_enqueue_style( 'table', plugins_url( '/css/table.css' ));
    //wp_localize_script( 'rml-script', 'readmelater_ajax', array( 'ajax_url' => plugins_url( '/save.php', __FILE__ )) );
}


add_action( 'wp_enqueue_scripts', 'select_response' );
add_shortcode('MYFORM', 'show_my_select' );

?>