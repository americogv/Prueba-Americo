<?php

require_once('../../../wp-config.php');
global $wpdb;
$current_user = wp_get_current_user();
$table_name = $wpdb->prefix . "bitacora";
$wpdb->insert( $table_name, array( 'fecha' => date('Y-m-d H:i:s'), 'usuario' => $current_user->user_login, 'detalle' => "El usuario selecciono la opcion ".$_POST['action']."." ) );

?>
