jQuery(document).ready(function( $ ) {
	
   $('#table').hide(); 
    $('#coments').change(function(){
        if($('#coments').val() == '0') {

        	$('#table').hide();
             
        } else {

        	var index=$('#coments').val() - 1;

        	$.getJSON('http://jsonplaceholder.typicode.com/posts/1/comments', function(jd) {
                  $('#table').html('<table id="datos" border="1"><tr><td><b>ID:</b> ' + jd[index].id + '</td></tr><tr><td><b>NAME:</b> ' + jd[index].name + '</td></tr><tr><td><b>EMAIL:</b> ' + jd[index].email + '</td><tr><td><b>BODY:</b> ' + jd[index].body + '</td></tr></tr></table>');
                  
               });

             var uri=$('#uri').val();
             
            $.ajax({
		            url : uri,
		            type : 'post',
		            data : {
		                action : $('#coments').val()
		            },
		            success : function( response ) {
		                //jQuery('.rml_contents').html(response);
		            }
		        });
            
            $('#table').show(); 
        } 
    });
	
}); 